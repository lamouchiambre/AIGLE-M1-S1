Binôme : Andréa Pires
Binôme : Alexandre Canton Condes

La gramaire AST fonctionne, mais la compilation avec le .java nous sort une erreur de parser.
(Malgré qu'on soit probablement proche d'avoir fini le tp.)


commandes :
antlr4 langageAST3.g4
javac langageAST3*.java
